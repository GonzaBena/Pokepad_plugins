# Test Hello World Plugin

This is a **test plugin** for PokePad to verify the plugin management UI.

## Features
- Greets the user in the console.
- Supports repetition counts.
- Demonstrates variable interpolation.

### Usage
Add this block to any workflow and set your custom message.
