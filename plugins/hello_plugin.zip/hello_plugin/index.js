module.exports = async (params, context, utils) => {
  const { message, count } = params;
  utils.log(`Executing test plugin with message: "${message}" (${count} times)`);
  
  for (let i = 0; i < (count || 1); i++) {
    console.log(`[Plugin:test.hello_world] ${i + 1}: ${message}`);
  }
  
  // Example of using context variables
  if (context.variables) {
     utils.log(`Available variables: ${Object.keys(context.variables).join(', ')}`);
  }
};
